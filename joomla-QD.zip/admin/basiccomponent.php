<?php
JToolBarHelper::title(JText::_('Basic Component'));
JToolBarHelper::preferences('com_basiccomponent');
?>

<p>Basic Component!</p>
