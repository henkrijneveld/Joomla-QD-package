<p>In the default.xml</p>
<iframe src="<?=$showurl?>" height="400" width="600"></iframe>